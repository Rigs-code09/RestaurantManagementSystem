package com.cts.client;

import com.cts.model.CustomerManagement;
import com.cts.model.MenuManagement;
import com.cts.model.OrderManagement;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            System.out.println("===== Restaurant Management System =====");
            System.out.println("1. Menu Management");
            System.out.println("2. Order Management");
            System.out.println("3. Customer Management");
            System.out.println("4. Exit");
            System.out.print("Select an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    manageMenu();
                    break;
                case 2:
                    manageOrders();
                    break;
                case 3:
                    manageCustomers();
                    break;
                case 4:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
        scanner.close();
    }

    private static void manageMenu()  {
        Scanner scanner = new Scanner(System.in);
        boolean back = false;

        while (!back) {
            System.out.println("===== Menu Management =====");
            System.out.println("1. Add Menu Item");
            System.out.println("2. View Menu Details");
            System.out.println("3. Update Menu Item");
            System.out.println("4. Delete Menu Item");
            System.out.println("5. Back");
            System.out.print("Select an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    MenuManagement.addMenuItem();
                    break;
                case 2:
                    MenuManagement.viewMenuDetails();
                    break;
                case 3:
                    MenuManagement.updateMenuItem();
                    break;
                case 4:
                    MenuManagement.deleteMenuItem();
                    break;
                case 5:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    private static void manageOrders() {
        Scanner scanner = new Scanner(System.in);
        boolean back = false;

        while (!back) {
            System.out.println("===== Order Management =====");
            System.out.println("1. Place Order");
            System.out.println("2. View Order Details");
            System.out.println("3. Update Order Status");
            System.out.println("4. Cancel Order");
            System.out.println("5. Back");
            System.out.print("Select an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    OrderManagement.placeOrder();
                    break;
                case 2:
                    OrderManagement.viewOrderDetails();
                    break;
                case 3:
                    OrderManagement.updateOrderStatus();
                    break;
                case 4:
                    OrderManagement.cancelOrder();
                    break;
                case 5:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    private static void manageCustomers() {
        Scanner scanner = new Scanner(System.in);
        boolean back = false;

        while (!back) {
            System.out.println("===== Customer Management =====");
            System.out.println("1. Register Customer");
            System.out.println("2. View Customer Details");
            System.out.println("3. Update Customer Information");
            System.out.println("4. Delete Customer");
            System.out.println("5. Back");
            System.out.print("Select an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    CustomerManagement.registerCustomer();
                    break;
                case 2:
                    CustomerManagement.viewCustomerDetails();
                    break;
                case 3:
                    CustomerManagement.updateCustomerInformation();
                    break;
                case 4:
                    CustomerManagement.deleteCustomer();
                    break;
                case 5:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

}




