package com.cts.exception;

public class PhonenumberException extends Exception{
    public PhonenumberException(String message){
        super(message);
    }
}
