package com.cts.exception;

public class IdnotexistException extends Exception {

    public IdnotexistException (String message){
        super(message);
    }
}
