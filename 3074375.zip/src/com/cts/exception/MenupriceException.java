package com.cts.exception;

public class MenupriceException extends Exception{

    public MenupriceException(String message){
        super(message);
    }
}
