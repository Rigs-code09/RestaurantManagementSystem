package com.cts.model;

import com.cts.exception.IdnotexistException;
import com.cts.exception.InvalidInputException;
import com.cts.exception.MenupriceException;
import com.cts.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class MenuManagement {

    public static void addMenuItem()  {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            String name = null;
            try {
                System.out.println("Enter item name:");
                name = scanner.nextLine();
                if (name.length() < 2) {
                    throw new InvalidInputException("Please input correct item name .");
                }
            } catch (InvalidInputException e) {
                System.out.println(e.getMessage());
            }

            System.out.println("Enter item description:");
            String description = scanner.nextLine();

            double price = 0;
            try {
                System.out.println("Enter item price:");
                price = scanner.nextDouble();
                if (price < 0) {
                    throw new MenupriceException("Please input positive value !");
                }
            } catch (MenupriceException e) {
                System.out.println(e.getMessage());
            }
            String sql = "INSERT INTO Menu (name, description, price, availability_status) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, description);
            pstmt.setDouble(3, price);
            pstmt.setBoolean(4, true);

            pstmt.executeUpdate();
            System.out.println("Menu item added successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewMenuDetails()  {

        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM Menu";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                System.out.println("Item ID: " + rs.getInt("item_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Description: " + rs.getString("description"));
                System.out.println("Price: " + rs.getDouble("price"));
                System.out.println("Availability: " + (rs.getBoolean("availability_status") ? "Available" : "Unavailable"));
                System.out.println("------------------------------");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static boolean itemExists(int itemId) {
        String query = "SELECT COUNT(*) FROM menu WHERE item_id = ?";
        Connection connection = null;
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, itemId);
            ResultSet resultSet = stmt.executeQuery();
            if (resultSet.next()) {
                return resultSet.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.out.println("SQL error occurred while checking item existence: " + e.getMessage());
        }
        return false;
    }

    public static void updateMenuItem() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.println("Enter item ID to update:");
            int itemId = scanner.nextInt();
            try {
                if (!itemExists(itemId)) {
                    throw new IdnotexistException("Id does not exist , enter valid id !");
                }
            } catch (IdnotexistException e) {
                System.out.println(e.getMessage());
                return;
            }

            System.out.println("Enter new item name:");
            String name = scanner.nextLine();

            System.out.println("Enter new item description:");
            String description = scanner.nextLine();

            System.out.println("Enter new item price:");
            double price = scanner.nextDouble();

            String sql = "UPDATE Menu SET name = ?, description = ?, price = ? WHERE item_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, description);
            pstmt.setDouble(3, price);
            pstmt.setInt(4, itemId);

            pstmt.executeUpdate();
            System.out.println("Menu item updated successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteMenuItem() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.println("Enter item ID to delete:");
            int itemId = scanner.nextInt();

            String sql = "DELETE FROM Menu WHERE item_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, itemId);

            pstmt.executeUpdate();
            System.out.println("Menu item deleted successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}


