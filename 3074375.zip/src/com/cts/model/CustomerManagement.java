package com.cts.model;

import com.cts.exception.PhonenumberException;
import com.cts.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class CustomerManagement {
    public static void registerCustomer() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.println("Enter customer name:");
            String name = scanner.nextLine();

            System.out.println("Enter customer email:");
            String email = scanner.nextLine();

            String phone = null;
            try {
                System.out.println("Enter customer phone number:");
                phone = scanner.nextLine();
                if (phone.length() != 10) {
                    throw new PhonenumberException("Enter 10 digit phone number !!");
                }
            } catch (PhonenumberException e) {
                System.out.println(e.getMessage());
                return;
            }

            System.out.println("Enter customer address:");
            String address = scanner.nextLine();

            String sql = "INSERT INTO Customer (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, phone);
            pstmt.setString(4, address);

            pstmt.executeUpdate();
            System.out.println("Customer registered successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewCustomerDetails() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM Customer";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Phone Number: " + rs.getString("phone_number"));
                System.out.println("Address: " + rs.getString("address"));
                System.out.println("------------------------------");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateCustomerInformation() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.println("Enter customer ID to update:");
            int customerId = scanner.nextInt();
            scanner.nextLine();

            System.out.println("Enter new customer name:");
            String name = scanner.nextLine();

            System.out.println("Enter new customer email:");
            String email = scanner.nextLine();

            System.out.println("Enter new customer phone number:");
            String phone = scanner.nextLine();

            System.out.println("Enter new customer address:");
            String address = scanner.nextLine();

            String sql = "UPDATE Customer SET name = ?, email = ?, phone_number = ?, address = ? WHERE customer_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, phone);
            pstmt.setString(4, address);
            pstmt.setInt(5, customerId);

            pstmt.executeUpdate();
            System.out.println("Customer information updated successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteCustomer() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.println("Enter customer ID to delete:");
            int customerId = scanner.nextInt();

            String sql = "DELETE FROM Customer WHERE customer_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, customerId);

            pstmt.executeUpdate();
            System.out.println("Customer deleted successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

