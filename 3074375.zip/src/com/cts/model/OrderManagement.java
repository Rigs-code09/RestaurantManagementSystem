package com.cts.model;

import com.cts.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class OrderManagement {
    public static void placeOrder() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.println("Enter item ID to order:");
            int itemId = scanner.nextInt();

            System.out.println("Enter customer ID:");
            int customerId = scanner.nextInt();

            String sql = "INSERT INTO Orders (item_id, customer_id, order_date, status) VALUES (?, ?, NOW(), 'placed')";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, itemId);
            pstmt.setInt(2, customerId);

            pstmt.executeUpdate();

            // Update the availability status in the Menu table
            String updateMenuSql = "UPDATE Menu SET availability_status = false WHERE item_id = ?";
            PreparedStatement updateMenuStmt = conn.prepareStatement(updateMenuSql);
            updateMenuStmt.setInt(1, itemId);
            updateMenuStmt.executeUpdate();

            System.out.println("Order placed successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewOrderDetails() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM Orders";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                System.out.println("Order ID: " + rs.getInt("order_id"));
                System.out.println("Item ID: " + rs.getInt("item_id"));
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Order Date: " + rs.getTimestamp("order_date"));
                System.out.println("Status: " + rs.getString("status"));
                System.out.println("------------------------------");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateOrderStatus() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.println("Enter order ID to update:");
            int orderId = scanner.nextInt();
            scanner.nextLine();

            System.out.println("Enter new status (placed/ready/cancelled):");
            String status = scanner.nextLine();

            String sql = "UPDATE Orders SET status = ? WHERE order_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, status);
            pstmt.setInt(2, orderId);

            pstmt.executeUpdate();
            System.out.println("Order status updated successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void cancelOrder() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.println("Enter order ID to cancel:");
            int orderId = scanner.nextInt();

            // Retrieve item_id for the order to update menu availability status
            String itemQuery = "SELECT item_id FROM Orders WHERE order_id = ?";
            PreparedStatement itemStmt = conn.prepareStatement(itemQuery);
            itemStmt.setInt(1, orderId);
            ResultSet rs = itemStmt.executeQuery();

            if (rs.next()) {
                int itemId = rs.getInt("item_id");

                // Update order status to 'cancelled'
                String sql = "UPDATE Orders SET status = 'cancelled' WHERE order_id = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setInt(1, orderId);
                pstmt.executeUpdate();

                // Update availability status in the Menu table
                String updateMenuSql = "UPDATE Menu SET availability_status = true WHERE item_id = ?";
                PreparedStatement updateMenuStmt = conn.prepareStatement(updateMenuSql);
                updateMenuStmt.setInt(1, itemId);
                updateMenuStmt.executeUpdate();

                System.out.println("Order cancelled successfully!");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

